<?php
$root='/userdata/wifi-manager';
$msg='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
  $ssid=trim($_POST['ssid'] ?? ''); $pass=$_POST['password'] ?? '';
  if ($ssid==='' || strlen($ssid)>32 || (strlen($pass)<8 || strlen($pass)>63)) $msg='SSID 或密码长度不正确';
  else {
    $cmd='/usr/sbin/wpa_passphrase '.escapeshellarg($ssid).' '.escapeshellarg($pass);
    $conf=preg_replace('/^\s*#psk=.*$/m','',shell_exec($cmd) ?: '');
    if ($conf) {
      file_put_contents('/tmp/rk3568-wifi-candidate.conf', $conf, LOCK_EX);
      file_put_contents('/tmp/rk3568-wifi-apply', "1\n", LOCK_EX);
      $msg='正在切换 Wi-Fi。约 30 秒后请使用新地址访问板子；失败时会恢复热点。';
    } else $msg='生成配置失败';
  }
}
$mode=@trim(file_get_contents($root.'/mode')) ?: 'station';
$ip=trim(shell_exec("ip -4 addr show wlan0 2>/dev/null | awk '/inet /{print \$2; exit}' | cut -d/ -f1"));
$scan=@file_get_contents($root.'/scan.txt') ?: '';
$nets=array_filter(array_map('trim',explode("\n",$scan ?: '')));
?><!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>RK3568 Wi-Fi 配置</title><style>
body{margin:0;background:#f4f6f8;font:16px system-ui;color:#17202a}.box{max-width:480px;margin:7vh auto;background:#fff;padding:26px;border-radius:16px;box-shadow:0 8px 30px #0002}h1{font-size:24px}label{display:block;margin-top:16px}input,select,button{box-sizing:border-box;width:100%;padding:13px;margin-top:7px;border:1px solid #ccd3da;border-radius:9px;font-size:16px}button{background:#1677ff;color:#fff;border:0;font-weight:600}.msg{padding:12px;background:#eef6ff;border-radius:8px}.small{color:#65717d;font-size:14px}</style></head><body><main class="box"><h1>RK3568 Wi-Fi 配置</h1><p class="small">当前模式：<?=htmlspecialchars($mode)?>　IP：<?=htmlspecialchars($ip ?: '未获取')?></p><?php if($msg):?><p class="msg"><?=htmlspecialchars($msg)?></p><?php endif?><form method="post"><label>Wi-Fi 名称</label><input name="ssid" list="nets" maxlength="32" required><datalist id="nets"><?php foreach($nets as $n):?><option value="<?=htmlspecialchars($n)?>"><?php endforeach?></datalist><label>Wi-Fi 密码</label><input name="password" type="password" minlength="8" maxlength="63" required><button type="submit">保存并连接</button></form><p class="small">热点默认密码：12345678。配置失败会自动恢复热点。</p></main></body></html>
